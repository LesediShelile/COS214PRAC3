#ifndef TECHNICALSUPPORT_H
#define TECHNICALSUPPORT_H

class TechnicalSupport{

};

#endif