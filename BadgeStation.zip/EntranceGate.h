#ifndef ENTRANCEGATE_H
#define ENTRANCEGATE_H

class EntranceGate{};


#endif