#ifndef VRSTATION_H
#define VRSTATION_H

class VRStation{


};
#endif