#ifndef EVENTCONTROL_H
#define EVENTCONTROL_H

class EventControl{};


#endif