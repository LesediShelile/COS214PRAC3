#ifndef EVENTNOTICE_H
#define EVENTNOTICE_H

#include <string>

class EventUnit;

/**
 * @brief Abstract push-notification payload used by EventFlow.
 *
 * Concrete notices use polymorphism to deliver the appropriate event action
 * without requiring controllers or observers to inspect a notice type.
 */
class EventNotice {
protected:
    std::string message;

public:
    explicit EventNotice(const std::string& message = "");
    virtual ~EventNotice() {}

    /** @return Name of this notice type. */
    virtual std::string getType() const = 0;

    /** @return Human-readable notice message. */
    std::string getMessage() const;

    /** @brief Dispatches this notice to the appropriate EventUnit behaviour. */
    virtual void dispatch(EventUnit& unit) const = 0;
};

/**
 * @brief Concrete event notice representing SafetyAlert.
 *
 * This notice participates as a concrete notification payload and dispatches
 * the corresponding action to an EventUnit polymorphically.
 */
class SafetyAlertNotice : public EventNotice {
public:
    explicit SafetyAlertNotice(const std::string& message = "");
    std::string getType() const override;
    void dispatch(EventUnit& unit) const override;
};

/**
 * @brief Concrete event notice representing CapacityAlert.
 *
 * This notice participates as a concrete notification payload and dispatches
 * the corresponding action to an EventUnit polymorphically.
 */
class CapacityAlertNotice : public EventNotice {
public:
    explicit CapacityAlertNotice(const std::string& message = "");
    std::string getType() const override;
    void dispatch(EventUnit& unit) const override;
};

/**
 * @brief Concrete event notice representing ServerOutage.
 *
 * This notice participates as a concrete notification payload and dispatches
 * the corresponding action to an EventUnit polymorphically.
 */
class ServerOutageNotice : public EventNotice {
public:
    explicit ServerOutageNotice(const std::string& message = "");
    std::string getType() const override;
    void dispatch(EventUnit& unit) const override;
};

/**
 * @brief Concrete event notice representing Evacuate.
 *
 * This notice participates as a concrete notification payload and dispatches
 * the corresponding action to an EventUnit polymorphically.
 */
class EvacuateNotice : public EventNotice {
public:
    explicit EvacuateNotice(const std::string& message = "");
    std::string getType() const override;
    void dispatch(EventUnit& unit) const override;
};

/**
 * @brief Concrete event notice representing ScheduleChange.
 *
 * This notice participates as a concrete notification payload and dispatches
 * the corresponding action to an EventUnit polymorphically.
 */
class ScheduleChangeNotice : public EventNotice {
public:
    explicit ScheduleChangeNotice(const std::string& message = "");
    std::string getType() const override;
    void dispatch(EventUnit& unit) const override;
};

/**
 * @brief Concrete event notice representing OpenArea.
 *
 * This notice participates as a concrete notification payload and dispatches
 * the corresponding action to an EventUnit polymorphically.
 */
class OpenAreaNotice : public EventNotice {
public:
    explicit OpenAreaNotice(const std::string& message = "");
    std::string getType() const override;
    void dispatch(EventUnit& unit) const override;
};

/**
 * @brief Concrete event notice representing CloseArea.
 *
 * This notice participates as a concrete notification payload and dispatches
 * the corresponding action to an EventUnit polymorphically.
 */
class CloseAreaNotice : public EventNotice {
public:
    explicit CloseAreaNotice(const std::string& message = "");
    std::string getType() const override;
    void dispatch(EventUnit& unit) const override;
};

/**
 * @brief Concrete event notice representing WeatherAlert.
 *
 * This notice participates as a concrete notification payload and dispatches
 * the corresponding action to an EventUnit polymorphically.
 */
class WeatherAlertNotice : public EventNotice {
public:
    explicit WeatherAlertNotice(const std::string& message = "");
    std::string getType() const override;
    void dispatch(EventUnit& unit) const override;
};

/**
 * @brief Concrete event notice representing TemporaryPause.
 *
 * This notice participates as a concrete notification payload and dispatches
 * the corresponding action to an EventUnit polymorphically.
 */
class TemporaryPauseNotice : public EventNotice {
public:
    explicit TemporaryPauseNotice(const std::string& message = "");
    std::string getType() const override;
    void dispatch(EventUnit& unit) const override;
};

/**
 * @brief Concrete event notice representing Resume.
 *
 * This notice participates as a concrete notification payload and dispatches
 * the corresponding action to an EventUnit polymorphically.
 */
class ResumeNotice : public EventNotice {
public:
    explicit ResumeNotice(const std::string& message = "");
    std::string getType() const override;
    void dispatch(EventUnit& unit) const override;
};

#endif
