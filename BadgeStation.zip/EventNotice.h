#ifndef EVENTNOTICE_H
#define EVENTNOTICE_H

class EventNotice{};

#endif