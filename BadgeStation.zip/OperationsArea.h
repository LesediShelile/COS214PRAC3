#ifndef OPERATIONSAREA_H
#define OPERATIONSAREA_H

class OperationsArea{};

#endif