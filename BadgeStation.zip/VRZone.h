#ifndef VRZONE_H
#define VRZONE_H

class VRZone{



};


#endif