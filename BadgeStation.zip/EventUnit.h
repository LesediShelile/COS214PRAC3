#ifndef EVENTUNIT_H
#define EVENTUNIT_H
#include "EventComponent.h"

class EventUnit : public EventComponent {};


#endif