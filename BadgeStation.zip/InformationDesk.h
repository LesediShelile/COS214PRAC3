#ifndef INFORMATIONDESK_H
#define INFORMATIONDESK_H
#include "RegistrationArea.h"

class InformationDesk : public RegistrationArea{};

#endif