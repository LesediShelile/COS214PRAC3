#ifndef VIPAREA_H
#define VIPAREA_H


class VIPArea{};

#endif