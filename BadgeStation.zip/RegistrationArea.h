#ifndef REGISTRATIONAREA_H
#define REGISTRATIONAREA_H


class RegistrationArea{};


#endif