#ifndef PRACTICEAREA_H
#define PRACTICEAREA_H

class PracticeArea{};

#endif