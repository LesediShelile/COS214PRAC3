#ifndef CHECKINDESK
#define CHECKINDESK
#include "RegistrationArea.h"

class CheckInDesk : public RegistrationArea{};

#endif