#ifndef CONVENTION_H
#define CONVENTION_H

class Convention{};

#endif