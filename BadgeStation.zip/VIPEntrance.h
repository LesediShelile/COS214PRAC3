#ifndef VIPENTRANCE_H
#define VIPENTRANCE_H

class VIPEntrance{

};


#endif