#ifndef MEDICALTEAM_H
#define MEDICALTEAM_H

class MedicalTeam{};


#endif