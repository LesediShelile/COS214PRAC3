#ifndef CHAMPIONSHIPARENA_H
#define CHAMPIONSHIPARENA_H

class ChampionshipArena{};

#endif