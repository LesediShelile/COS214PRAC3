#ifndef MEDICALAREA_H
#define MEDICALAREA_H

class MedicalArea{};

#endif