#ifndef SECURITYAREA_H
#define SECURITYAREA_H


class SecurityArea{};


#endif