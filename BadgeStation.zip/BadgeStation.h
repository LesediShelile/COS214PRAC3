#ifndef BADGESTATION_H
#define BADGESTATION_H
#include "RegistrationArea.h"

class BadgeStatioon :public RegistrationArea{};

#endif