#ifndef PRIVATEDEMOAREA_H
#define PRIVATEDEMOAREA_H

class PrivateDemoArea{};

#endif