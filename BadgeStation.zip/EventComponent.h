#ifndef EVENTCOMPONENT_H
#define EVENTCOMPONENT_H

class EventComponent{};


#endif