#ifndef REFEREETEAM_H
#define REFEREETEAM_H

class RefereeTeam{};

#endif