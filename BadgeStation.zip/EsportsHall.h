#ifndef ESPORTSHALL_H
#define ESPORTSHALL_H

class EsportsHall{};


#endif